#!/usr/bin/env python3
"""
上标字母转换工具
参数说明：
  -s 文本  : 转为上标 (superscript)
  -b 文本  : 转为普通 (back to normal)
"""

import sys

# 上标映射表
M = {'A':'ᴬ','B':'ᴮ','C':'ᶜ','D':'ᴰ','E':'ᴱ','F':'ᶠ','G':'ᴳ','H':'ᴴ','I':'ᴵ','J':'ᴶ',
     'K':'ᴷ','L':'ᴸ','M':'ᴹ','N':'ᴺ','O':'ᴼ','P':'ᴾ','Q':'ᵠ','R':'ᴿ','S':'ˢ','T':'ᵀ',
     'U':'ᵁ','V':'ⱽ','W':'ᵂ','X':'ˣ','Y':'ʸ','Z':'ᶻ','a':'ᵃ','b':'ᵇ','c':'ᶜ','d':'ᵈ',
     'e':'ᵉ','f':'ᶠ','g':'ᵍ','h':'ʰ','i':'ᶦ','j':'ʲ','k':'ᵏ','l':'ˡ','m':'ᵐ','n':'ⁿ',
     'o':'ᵒ','p':'ᵖ','q':'ᑫ','r':'ʳ','s':'ˢ','t':'ᵗ','u':'ᵘ','v':'ᵛ','w':'ʷ','x':'ˣ',
     'y':'ʸ','z':'ᶻ','0':'⁰','1':'¹','2':'²','3':'³','4':'⁴','5':'⁵','6':'⁶','7':'⁷',
     '8':'⁸','9':'⁹'}

# 反向映射
R = {v:k for k,v in M.items()}

if len(sys.argv) != 3:
    print("用法: python script.py -s 文本  # 转为上标")
    print("      python script.py -b 文本  # 转为普通")
    sys.exit(1)

mode, text = sys.argv[1], sys.argv[2]

if mode == '-s':  # 转为上标
    print(''.join(M.get(c, c) for c in text))
elif mode == '-b':  # 转为普通
    print(''.join(R.get(c, c) for c in text))
else:
    print("错误: 参数必须是 -s 或 -b")